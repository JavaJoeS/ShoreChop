package org.eclipse.core.security;

import java.security.Provider;

public class CustomProvider extends Provider {

	private static final long serialVersionUID = 1L;

	public CustomProvider() {
		super("specialProvider", "1.0", "Custom Provider wrapper");
		
	}
}
