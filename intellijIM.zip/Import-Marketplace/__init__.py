
#Python code to illustrate parsing of XML files 
# importing the required modules 
import os
import sys
import shutil
import time
import requests 
import json
import xml.etree.ElementTree as ET 
from pathlib import Path

HomeDir = "/mirror/intellij/"
FilesDir = HomeDir + "files/"
dirPath = ""
JetBrainsURL = 'https://plugins.jetbrains.com'
JsonData = []
Found = 0
NotFound = 0

#
# query for the XMLIds
#
def loadXMLIds(buildId): 
    
    # url of pluginsXMLIds.json
    url = JetBrainsURL+"/files/pluginsXMLIds.json?build="+buildId
    resp = requests.get(url) 
  
    # saving the json file 
    with open(os.path.join(FilesDir, 'pluginsXMLIds.json'), 'wb') as f: 
        f.write(resp.content) 
    
#
# query for all plugins we can install in this version of intelliJ
# in json format
#
def loadJSON(buildId, dirPath): 
    global JsonData
    
    # url of rss feed 
    url = JetBrainsURL+"/api/search/plugins?max=6000&build="+buildId
    #url = JetBrainsURL+"/api/search/plugins?build="+buildId
    # creating HTTP response object from given url 
    resp = requests.get(url) 
  
    # saving the xml file 
    with open(os.path.join(dirPath, 'index.json'), 'wb') as f: 
        f.write(resp.content) 

    JsonData = json.loads(resp.content.decode('utf-8'))
    #for p in JsonData:
    #    print(p['xmlId'])
    #print(list(JsonData))
     
#
# query for all plugins we can install in this version of intelliJ
# in json format
#
def loadAggregations(buildId): 
    
    # url of tags
    resp = requests.get(JetBrainsURL+"/api/search/aggregation/tags") 
  
    # saving the xml file 
    with open(os.path.join(dirPath, 'tags.json'), 'wb') as f: 
        f.write(resp.content) 

    # url of organizations 
    resp = requests.get(JetBrainsURL+"/api/search/aggregation/organizations") 
  
    # saving the xml file 
    with open(os.path.join(dirPath, 'organizations.json'), 'wb') as f: 
        f.write(resp.content) 

    # url of organizations 
    resp = requests.get(JetBrainsURL+"/api/search/aggregation/organizations") 
  
    # saving the xml file 
    with open(os.path.join(dirPath, 'organizations.json'), 'wb') as f: 
        f.write(resp.content)     
         
#
# downloads the meta Jon and returns a string of the module name and version
#     
def getMetaJson(id, updateId):
    url = JetBrainsURL+"/files/" + str(id) + "/" + str(updateId) + "/meta.json"
    resp = requests.get(url) 
    
    # make directories
    try:
        os.makedirs(os.path.join(FilesDir, str(id), str(updateId)), exist_ok=True)
    except OSError as error:
        print(error)   
        
    # saving the xml file 
    with open(os.path.join(FilesDir, str(id), str(updateId), 'meta.json'), 'wb') as f: 
        f.write(resp.content) 
    
    metaJson = json.loads(resp.content.decode('utf-8'))
    
    return metaJson["xmlId"] + "-" + metaJson["version"]

   
#
# query for all plugins we can install in this version of intelliJ
#
def loadXML(buildId, dirPath): 
  
    # url of rss feed 
    url = JetBrainsURL+"/plugins/list/?build="+buildId
  
    # creating HTTP response object from given url 
    resp = requests.get(url) 
  
    # saving the xml file 
    with open(os.path.join(dirPath, 'index.xml'), 'wb') as f: 
        f.write(resp.content)   
        
        
        
def FindNameJson(Name):
    global Found
    global NotFound
    for p in JsonData:
        #print("### " + p['xmlId'] + " " + Name)
        if (p['xmlId'] == Name):
            # print ("#### Found #### %s" % Name ) 
            Found = Found+1
            return p
    print ("### Name not found %s" % Name )
    NotFound = NotFound+1    
    return {}
    
    
def GetIcon(Name, id, updateId, buildId):
    # url of icon 
    #headers = {"User-Agent":"IntelliJ IDEA/202.7660.26"}
    #url = JetBrainsURL+"/api/icon/?pluginId="+Name

    url = JetBrainsURL+"/files/"+str(id)+"/"+str(updateId)+"/icon/pluginIcon.svg"
  
    # creating HTTP response object from given url 
    resp = requests.get(url) 
    print("Icon is: " + url)
    print("status: " + str(resp.status_code))

    #
    # At this point the first query succeeded, or it failed and we tried the backup
    #
    if (resp.status_code == 200):
        IconDir = os.path.join(HomeDir, "icons")
    
        try: 
            os.mkdir(IconDir)
        except OSError as error:
            pass
  
        #
        # If we got a good response code download the file. 
        #
        with open(os.path.join(IconDir, Name + ".svg"), 'wb') as f: 
            f.write(resp.content)    
            
        with open(os.path.join(FilesDir, str(id), str(updateId), "default.svg"), 'wb') as f:
            f.write(resp.content)  
    
#
# parse the index file the list of plugins we need to mirror..
#
def parseXML(xmlfile, dirPath, buildId): 
  
    # create element tree object 
    tree = ET.parse(xmlfile) 
    
    # get root element 
    root = tree.getroot();
  
    count = 0;
    
    #
    # write the file in xml format
    #
    tree.write(os.path.join(dirPath, 'index2.xml'), encoding='utf-8', method="xml")
    
    #
    # iterate through the categories
    #
    for cat in root.findall('./category'):
        
        #
        # iterate through the plugin list
        #
        for item in cat.findall('./idea-plugin'):
        
            #
            # pick out some useful info from the plugin
            #
            name = item.find("name");
            id = item.find("id");
            vendor = item.find("vendor");
            author = vendor.get("email");

            #
            # find the entry in the json
            #
            JsonEntry = FindNameJson(id.text);
            if (JsonEntry):
                print(JsonEntry)
                print (name.text + " " + id.text + " " + author + " {:d} {:d}".format(JsonEntry['id'], JsonEntry['updateId']))
        
                #
                # need to check here for things we should not mirror. 
                #
                if (author.endswith(".ru") or id.text.startswith("ru.") or  
                    author.endswith("huawei.com") or id.text.startswith("com.huawei") or 
                    author.endswith(".il") or id.text.startswith("il.") or 
                    author.endswith("alibaba.com") or id.text.startswith("com.alibaba") or
                    author.endswith(".cn") or id.text.startswith("cn.")):
                    print ("*** Skipping due to source ***")
                    cat.remove(item)
                    continue
           
                #
                # download the update site
                #
                idstr = id.text.rstrip("/")  # remove any trailing slashes 
                pluginNameVer = getMetaJson(JsonEntry['id'], JsonEntry['updateId'])
                if (getUpdateSite(idstr, JsonEntry['id'], JsonEntry['updateId'], pluginNameVer, buildId)):  
                    GetIcon(idstr, JsonEntry['id'], JsonEntry['updateId'], buildId)      
                    # be nice to the server
                    time.sleep(10)
        
            count = count + 1
        
            #
            # debug early exit 
            #
            #if (count > 10):
            #    exit()
    return

#
# download the update site as a zip file Returns true if site contacted.
#
def getUpdateSite(site, id, updateId, pluginNameVer, buildId):

    url = JetBrainsURL + "/pluginManager?action=download&id="+site+"&build="+buildId
    print(url);

    try:
        filename = os.path.join(FilesDir, str(id), str(updateId), pluginNameVer+".zip")
        #filename = site.replace("/", "-")
        #filename = filename.replace(" ", "-")
    
        print(filename)
       
        out_file = Path(filename)
        if (out_file.exists()):
           print ("Output File " + filename + " already exists skipping")
           return False
    
        updatefile = requests.get(url)
        open(filename, 'xb').write(updatefile.content)

    except:
        e = sys.exc_info()[0]
        print ("**** skipping " + site + "due to %s ****" % e)
       
    return True
  
      
def main(buildId): 
    global dirPath
    print ("IntelliJ version -> " + buildId)
    
    dirPath = os.path.join(HomeDir, buildId)
    
    #delete directory if it exists 
    try:
      shutil.rmtree(dirPath, ignore_errors=False)
    except:
      print('Error while deleting directory %s %s' % (dirPath, sys.exc_info()[0]))
      
    # make the directory for this IntelliJ version
    os.mkdir(dirPath)
      
    try:
      os.mkdir(FilesDir)
    except:
      print('File Dir already exists.')
    
    # load the xml and Json index files
    loadXML(buildId, dirPath) 
    loadJSON(buildId, dirPath)
    loadAggregations(buildId)
    loadXMLIds(buildId)
    
    
    # parse xml file 
    parseXML(os.path.join(dirPath, 'index.xml'), dirPath, buildId) 
    print ("Found {:d}; NotFound {:d}".format(Found, NotFound))
      
      
if __name__ == "__main__": 
  
    if (len(sys.argv) < 2):
       print ("Import-Marketplace <IntelliJ version>")
       exit(1)
       
    # calling main function 
    main(sys.argv[1]) 
